// main.js

$(document).ready(function (){
	console.log('document is ready bitch');
});
